Live Inference and Benchmark CT-scan Data with OpenVINO
=======================================================

This tutorial is part of a series on how to train, optimize, quantize
and show live inference on a medical segmentation model. The goal is to
accelerate inference on a kidney segmentation model. The
`UNet <https://arxiv.org/abs/1505.04597>`__ model is trained from
scratch; the data is from
`Kits19 <https://github.com/neheller/kits19>`__.

This tutorial shows how to

-  Benchmark performance of the model
-  Show live inference with OpenVINO’s async API and MULTI plugin

To learn how this model was quantized, please see the `Convert and
Quantize a UNet Model and Show Live
Inference <110-ct-segmentation-quantize-with-output.html>`__
tutorial.

Instructions
------------

This notebook needs a quantized OpenVINO IR model. We provide a
pretrained model trained for 20 epochs with the full
`Kits-19 <https://github.com/neheller/kits19>`__ frames dataset, which
has an F1 score on the validation set of 0.9. The training code is
available in the `PyTorch Monai
Training <110-ct-segmentation-quantize-with-output.html>`__
notebook. It also needs images from the Kits19 dataset, converted to 2D
images. For demonstration purposes, this tutorial will download one
converted CT scan to use for inference.

Imports
-------

.. code:: ipython3

    import os
    import sys
    import zipfile
    from pathlib import Path
    
    import numpy as np
    from monai.transforms import LoadImage
    from openvino.inference_engine import IECore
    
    sys.path.append("../utils")
    from models.custom_segmentation import SegmentationModel
    from notebook_utils import benchmark_model, download_file, show_live_inference

Settings
--------

To use the pretrained models, set ``IR_PATH`` to
``"pretrained_model/unet44.xml"`` and ``COMPRESSED_MODEL_PATH`` to
``"pretrained_model/quantized_unet44.xml"``. To use a model that you
trained or optimized yourself, adjust the model paths.

.. code:: ipython3

    # The directory that contains the IR model (xml and bin) files
    MODEL_PATH = "pretrained_model/quantized_unet_kits19.xml"
    # Uncomment the next line to use the FP16 model instead of the quantized model
    # MODEL_PATH = "pretrained_model/unet_kits19.xml"

Benchmark Model Performance
---------------------------

To measure the inference performance of the IR model, we use `Benchmark
Tool <https://docs.openvino.ai/latest/openvino_inference_engine_tools_benchmark_tool_README.html>`__,
OpenVINO’s inference performance measurement tool. Benchmark tool is a
command line application that can be run in the notebook with
``! benchmark_app`` or ``%sx benchmark_app``.

In this tutorial, we use a wrapper function from `Notebook
Utils <https://github.com/openvinotoolkit/openvino_notebooks/blob/main/notebooks/utils/notebook_utils.ipynb>`__.
It prints the ``benchmark_app`` command with the chosen parameters.

   NOTE: For the most accurate performance estimation, we recommended
   running ``benchmark_app`` in a terminal/command prompt after closing
   other applications. Run ``benchmark_app --help`` to see all command
   line options.

.. code:: ipython3

    ie = IECore()
    # By default, benchmark on MULTI:CPU,GPU if a GPU is available, otherwise on CPU.
    device = "MULTI:CPU,GPU" if "GPU" in ie.available_devices else "CPU"
    # Uncomment one of the options below to benchmark on other devices
    # device = "GPU"
    # device = "CPU"
    # device = "AUTO"

.. code:: ipython3

    # Benchmark model
    benchmark_model(model_path=MODEL_PATH, device=device, seconds=15)



**Benchmark quantized_unet_kits19.xml with CPU for 15 seconds with async
inference**



Benchmark command:
``benchmark_app -m pretrained_model/quantized_unet_kits19.xml -d CPU -t 15 -api async -b 1 -cdir model_cache``


.. parsed-literal::

    Count:          1542 iterations
    Duration:       15071.90 ms
    Latency:
        Median:     58.41 ms
        AVG:        58.46 ms
        MIN:        50.68 ms
        MAX:        78.62 ms
    Throughput: 102.31 FPS
    
    Device: Intel(R) Core(TM) i9-10920X CPU @ 3.50GHz


Download and Prepare Data
-------------------------

Download one validation video for live inference. We reuse the
KitsDataset class that was also used in the training and quantization
notebook that will be released later.

Data is expected in ``BASEDIR`` defined in the Settings cell.
``BASEDIR`` should contain directories named ``case_00000`` to
``case_00299``. If data for the case specified above does not exist yet,
it will be downloaded and extracted in the next cell.

.. code:: ipython3

    # Directory that contains the CT scan data. This directory should contain subdirectories
    # case_00XXX where XXX is between 000 and 299
    BASEDIR = Path("kits19_frames_1")
    # The CT scan case number. For example: 16 for data from the case_00016 directory
    # Currently only 117 is supported
    CASE = 117
    
    case_path = BASEDIR / f"case_{CASE:05d}"
    
    if not case_path.exists():
        filename = download_file(
            f"https://storage.openvinotoolkit.org/data/test_data/openvino_notebooks/kits19/case_{CASE:05d}.zip"
        )
        with zipfile.ZipFile(filename, "r") as zip_ref:
            zip_ref.extractall(path=BASEDIR)
        os.remove(filename)  # remove zipfile
        print(f"Downloaded and extracted data for case_{CASE:05d}")
    else:
        print(f"Data for case_{CASE:05d} exists")



.. parsed-literal::

    case_00117.zip:   0%|          | 0.00/5.48M [00:00<?, ?B/s]


.. parsed-literal::

    Downloaded and extracted data for case_00117


Show Live Inference
-------------------

To show live inference on the model in the notebook, we use the
asynchronous processing feature of OpenVINO Inference Engine.

If you use a GPU device, with ``device="GPU"`` or
``device="MULTI:CPU,GPU"`` to do inference on an integrated graphics
card, model loading will be slow the first time you run this code. The
model will be cached, so after the first time model loading will be
fast. See the `OpenVINO API
tutorial <002-openvino-api-with-output.html>`__ for more
information on Inference Engine, including Model Caching.

We use the ``show_live_inference`` function from `Notebook
Utils <utils-with-output.html>`__ to show live inference. This
function uses `Open Model
Zoo <https://github.com/openvinotoolkit/open_model_zoo/>`__\ ’s
AsyncPipeline and Model API to perform asynchronous inference. After
inference on the specified CT scan has completed, the total time and
throughput (fps), including preprocessing and displaying, will be
printed.

Load Model and List of Image Files
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Load the segmentation model to Inference Engine with
``SegmentationModel``, based on the `Open Model
Zoo <https://github.com/openvinotoolkit/open_model_zoo/>`__ Model API.
This model implementation includes pre and post processing for the
model. For ``SegmentationModel`` this includes the code to create an
overlay of the segmentation mask on the original image/frame. Uncomment
the next cell to see the implementation.

.. code:: ipython3

    # SegmentationModel??

.. code:: ipython3

    ie = IECore()
    segmentation_model = SegmentationModel(
        ie=ie, model_path=Path(MODEL_PATH), sigmoid=True, rotate_and_flip=True
    )
    image_paths = sorted(case_path.glob("imaging_frames/*jpg"))
    
    print(f"{case_path.name}, {len(image_paths)} images")


.. parsed-literal::

    case_00117, 69 images


Show Inference
~~~~~~~~~~~~~~

In the next cell, we run the ``show live_inference`` function, which
loads the ``segmentation_model`` to the specified ``device`` (using
caching for faster model loading on GPU devices), loads the images,
performs inference, and displays the results on the frames loaded in
``images`` in real-time.

We use ``reader=LoadImage()`` to read the images in the same way as in
the
`training <110-ct-segmentation-quantize-with-output.html>`__
tutorial.

.. code:: ipython3

    # Possible options for device include "CPU", "GPU", "AUTO", "MULTI"
    device = "MULTI:CPU,GPU" if "GPU" in ie.available_devices else "CPU"
    reader = LoadImage(image_only=True, dtype=np.uint8)
    
    show_live_inference(
        ie=ie, image_paths=image_paths, model=segmentation_model, device=device, reader=reader
    )



.. image:: 210-ct-scan-live-inference-with-output_files/210-ct-scan-live-inference-with-output_15_0.jpg


.. parsed-literal::

    Loaded model to CPU in 0.23 seconds.
    Total time for 68 frames: 1.86 seconds, fps:37.07

