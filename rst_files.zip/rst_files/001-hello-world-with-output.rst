Hello Image Classification
==========================

A very basic introduction to OpenVINO that shows how to perform
inference with an image classification model.

We use a pre-trained `MobileNetV3
model <https://docs.openvino.ai/latest/omz_models_model_mobilenet_v3_small_1_0_224_tf.html>`__
from the `Open Model
Zoo <https://github.com/openvinotoolkit/open_model_zoo/>`__. See the
`TensorFlow to
OpenVINO <101-tensorflow-to-openvino-with-output.html>`__
tutorial to learn more about how OpenVINO IR model like this one is
created.

Imports
-------

.. code:: ipython3

    import cv2
    import matplotlib.pyplot as plt
    import numpy as np
    from openvino.runtime import Core

Load the Model
--------------

.. code:: ipython3

    ie = Core()
    model = ie.read_model(model="model/v3-small_224_1.0_float.xml")
    compiled_model = ie.compile_model(model=model, device_name="CPU")
    
    output_layer = compiled_model.output(0)

Load an Image
-------------

.. code:: ipython3

    # The MobileNet model expects images in RGB format
    image = cv2.cvtColor(cv2.imread(filename="data/coco.jpg"), code=cv2.COLOR_BGR2RGB)
    
    # resize to MobileNet image shape
    input_image = cv2.resize(src=image, dsize=(224, 224))
    
    # reshape to model input shape
    input_image = np.expand_dims(input_image, 0)
    plt.imshow(image);



.. image:: 001-hello-world-with-output_files/001-hello-world-with-output_6_0.png


Do Inference
------------

.. code:: ipython3

    result_infer = compiled_model([input_image])[output_layer]
    result_index = np.argmax(result_infer)

.. code:: ipython3

    # Convert the inference result to a class name.
    imagenet_classes = open("utils/imagenet_2012.txt").read().splitlines()
    
    # The model description states that for this model, class 0 is background,
    # so we add background at the beginning of imagenet_classes
    imagenet_classes = ['background'] + imagenet_classes
    
    imagenet_classes[result_index]




.. parsed-literal::

    'n02099267 flat-coated retriever'


